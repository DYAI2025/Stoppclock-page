Use your Writing-Plans skill.
